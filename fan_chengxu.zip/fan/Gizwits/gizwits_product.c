/**
************************************************************
* @file         gizwits_product.c
* @brief        Gizwits control protocol processing, and platform-related       hardware initialization 
* @author       Gizwits
* @date         2017-07-19
* @version      V03030000
* @copyright    Gizwits
* 
* @note         机智云.只为智能硬件而生
*               Gizwits Smart Cloud  for Smart Products
*               链接|增值ֵ|开放|中立|安全|自有|自由|生态
*               www.gizwits.com
*
***********************************************************/

#include <stdio.h>
#include <string.h>
#include "gizwits_product.h"
#include "common.h"
#include "gpio.h"
#include "Hal_temp_hum.h"
#include "adc.h"
#include "tim.h"
#include "motor.h"

static uint32_t timerMsCount;
uint8_t aRxBuffer;


extern uint16_t mode_follow ;

/** User area the current device state structure*/
dataPoint_t currentDataPoint;

extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;

volatile uint32_t soc = 84; // 计时变量

#define Temp_alarm  32   //温度上限（单位：C）
#define Humi_alarm  90   //湿度上限（单位：%）
#define Gas_alarm  200   //有害气体浓度上限（单位：PPM）
#define Elec_alarm  20   //最低电量（单位：%）

uint8_t Temperature = 0;
uint8_t Humidity = 0;
uint8_t Gas = 0;

/**
* 用户数据获取

* 此处需要用户实现除可写数据点之外所有传感器数据的采集,可自行定义采集频率和设计数据过滤算法
* @param none
* @return none
*/
#define  SAMPLING_TIME1_MAX  2000


/**@} */
/**@name Gizwits User Interface
* @{
*/

/**
* @brief Event handling interface

* Description:

* 1. Users can customize the changes in WiFi module status

* 2. Users can add data points in the function of event processing logic, such as calling the relevant hardware peripherals operating interface

* @param [in] info: event queue
* @param [in] data: protocol data
* @param [in] len: protocol data length
* @return NULL
* @ref gizwits_protocol.h
*/
int8_t gizwitsEventProcess(eventInfo_t *info, uint8_t *gizdata, uint32_t len) {
    uint8_t i = 0;
    dataPoint_t *dataPointPtr = (dataPoint_t *) gizdata;
    moduleStatusInfo_t *wifiData = (moduleStatusInfo_t *) gizdata;
    protocolTime_t *ptime = (protocolTime_t *) gizdata;

#if MODULE_TYPE
    gprsInfo_t *gprsInfoData = (gprsInfo_t *)gizdata;
#else
    moduleInfo_t *ptModuleInfo = (moduleInfo_t *) gizdata;
#endif

    if ((NULL == info) || (NULL == gizdata)) {
        return -1;
    }

    for (i = 0; i < info->num; i++) {
        switch (info->event[i]) {
            case EVENT_Automatic_follow:
                currentDataPoint.valueAutomatic_follow = dataPointPtr->valueAutomatic_follow;
                GIZWITS_LOG("Evt: EVENT_Automatic_follow %d \n", currentDataPoint.valueAutomatic_follow);
                if (0x01 == currentDataPoint.valueAutomatic_follow) {
                    //user handle
                    mode_follow = 1;//自动跟随功能开启
                } else {
                    //user handle
                    mode_follow = 0;//自动跟随功能关闭
                }
                break;
            case EVENT_fan:
                currentDataPoint.valuefan = dataPointPtr->valuefan;
                GIZWITS_LOG("Evt: EVENT_fan %d \n", currentDataPoint.valuefan);
                if (0x01 == currentDataPoint.valuefan) {
                    //user handle
                    relay1 = 1;//打开风扇
                } else {
                    //user handle
                    relay1 = 0;//关闭风扇
                }
                break;
            case EVENT_Wireless_charging:
                currentDataPoint.valueWireless_charging = dataPointPtr->valueWireless_charging;
                GIZWITS_LOG("Evt: EVENT_Wireless_charging %d \n", currentDataPoint.valueWireless_charging);
                if (0x01 == currentDataPoint.valueWireless_charging) {
                    //user handle
                    relay6 = 1;//打开无线充电模式
                } else {
                    //user handle
                    relay6 = 0;//关闭无线充电模式
                }
                break;

            case EVENT_Fan_lift:
                currentDataPoint.valueFan_lift = dataPointPtr->valueFan_lift;
                GIZWITS_LOG("Evt: EVENT_Fan_lift %d\n", currentDataPoint.valueFan_lift);
                switch (currentDataPoint.valueFan_lift) {
                    case Fan_lift_VALUE0:
                        //user handle
                    Fan_stop;//风扇停止
                        break;
                    case Fan_lift_VALUE1:
                        //user handle
                    Fan_up;//风扇上升
                        break;
                    case Fan_lift_VALUE2:
                        //user handle
                    Fan_down;//风扇下降
                        break;
                    default:
                        break;
                }
                break;


            case WIFI_SOFTAP:
                break;
            case WIFI_AIRLINK:
                break;
            case WIFI_STATION:
                break;
            case WIFI_CON_ROUTER:

                break;
            case WIFI_DISCON_ROUTER:

                break;
            case WIFI_CON_M2M:

                break;
            case WIFI_DISCON_M2M:
                break;
            case WIFI_RSSI:
                GIZWITS_LOG("RSSI %d\n", wifiData->rssi);
                break;
            case TRANSPARENT_DATA:
                GIZWITS_LOG("TRANSPARENT_DATA \n");
                //user handle , Fetch data from [data] , size is [len]
                break;
            case WIFI_NTP:
                GIZWITS_LOG("WIFI_NTP : [%d-%d-%d %02d:%02d:%02d][%d] \n", ptime->year, ptime->month, ptime->day,
                            ptime->hour, ptime->minute, ptime->second, ptime->ntp);
                break;
            case MODULE_INFO:
                GIZWITS_LOG("MODULE INFO ...\n");
#if MODULE_TYPE
                GIZWITS_LOG("GPRS MODULE ...\n");
                //Format By gprsInfo_t
#else
                GIZWITS_LOG("WIF MODULE ...\n");
                //Format By moduleInfo_t
                GIZWITS_LOG("moduleType : [%d] \n", ptModuleInfo->moduleType);
#endif
                break;
            default:
                break;
        }
    }

    return 0;
}

/**
* User data acquisition

* Here users need to achieve in addition to data points other than the collection of data collection, can be self-defined acquisition frequency and design data filtering algorithm

* @param none
* @return none
*/
void userHandle(void) {
    /*
       currentDataPoint.valueTemperature = ;//Add Sensor Data Collection
       currentDataPoint.valueHumidity = ;//Add Sensor Data Collection
       currentDataPoint.valuePower_rating = ;//Add Sensor Data Collection
       currentDataPoint.valueGas = ;//Add Sensor Data Collection
       currentDataPoint.valueTemperature_alarm = ;//Add Sensor Data Collection
       currentDataPoint.valueHumidity_alarm = ;//Add Sensor Data Collection
       currentDataPoint.valueGas_alarmm = ;//Add Sensor Data Collection
       currentDataPoint.valuePower_low = ;//Add Sensor Data Collection

       */
    static uint32_t thLastTimer1 = 0;
    static uint16_t ADC_Value;
    uint8_t ret = 0;
    static uint16_t Value[30];
    int16_t max,min;

    if (relay1 == 0)
        currentDataPoint.valuefan = 0;
    else
        currentDataPoint.valuefan = 1;

    if (relay2 == 0 && relay3 == 0 && relay4 == 0 && relay5 == 0)
        currentDataPoint.valueFan_lift = 0;
    else if (relay2 == 1 && relay3 == 1 && relay4 == 0 && relay5 == 0)
        currentDataPoint.valueFan_lift = 1;
    else if (relay2 == 0 && relay3 == 0 && relay4 == 1 && relay5 == 1)
        currentDataPoint.valueFan_lift = 2;

    if (relay6 == 0)
        currentDataPoint.valueWireless_charging = 0;
    else
        currentDataPoint.valueWireless_charging = 1;

    if ( mode_follow == 0)
        currentDataPoint.valueAutomatic_follow = 0;
    else
        currentDataPoint.valueAutomatic_follow = 1;

    if ((gizGetTimerCount() - thLastTimer1) > SAMPLING_TIME1_MAX) {
        ret = dht11Read((uint8_t *) &Temperature, (uint8_t *) &Humidity);
        if (ret != 0) {
            printf("Failed to read DHT11\r\n");
        } else {
            currentDataPoint.valueTemperature = Temperature;//Add Sensor Data Collection
            currentDataPoint.valueHumidity = Humidity;//Add Sensor Data Collection
            if (Temperature >= Temp_alarm) {
                currentDataPoint.valueTemperature_alarm = 1;//温度达上限报警
            } else {
                currentDataPoint.valueTemperature_alarm = 0;
            }
            if (Humidity >= Humi_alarm) {
                currentDataPoint.valueHumidity_alarm = 1;//湿度达上限报警
            } else {
                currentDataPoint.valueHumidity_alarm = 0;
            }
        }

        //有害气体浓度部分

        for(char n=0;n<22;n++)
        {//取22个值做滤波用
            HAL_ADC_Start(&hadc1);
            HAL_ADC_PollForConversion(&hadc1, 10);    //等待转换完成，第二个参数表示超时时间，单位ms
            if(HAL_IS_BIT_SET(HAL_ADC_GetState(&hadc1), HAL_ADC_STATE_REG_EOC))
            {
                Value[n]=HAL_ADC_GetValue(&hadc1);
                ADC_Value += Value[n];
            }
        }
        max=Value[0];
        min=Value[0];
        for(char n=0;n<22;n++)//取最大值、最小值
        {
            max=(Value[n]<max)?max:Value[n];
            min=(min<Value[n])?min:Value[n];
        }
        Gas = (ADC_Value -max-min)/20 * 3300 / 4095;
        ADC_Value=0;

//        HAL_ADC_Start(&hadc1);     //启动ADC转换
//        HAL_ADC_PollForConversion(&hadc1, 50);   //等待转换完成，50为最大等待时间，单位为ms
//        ADC_Value = HAL_ADC_GetValue(&hadc1);   //获取AD值
//        Gas = ADC_Value * 3300 / 4095;
        currentDataPoint.valueGas = Gas;
        if (Gas >= Gas_alarm) {
            currentDataPoint.valueGas_alarmm = 1;//有害气体浓度达上限报警
        } else {
            currentDataPoint.valueGas_alarmm = 0;
        }

        thLastTimer1 = gizGetTimerCount();
    }

    currentDataPoint.valuePower_rating = soc;
    if (soc <= Elec_alarm) {
        currentDataPoint.valuePower_low = 1;//电池电量过低报警报警
    } else {
        currentDataPoint.valuePower_low = 0;
    }

}

/**
* Data point initialization function

* In the function to complete the initial user-related data
* @param none
* @return none
* @note The developer can add a data point state initialization value within this function
*/
void userInit(void) {
    dht11Init(); //温湿度传感器DHT11初始化
    MQ135Init(); //有害气体传感器MQ135初始化
    motor_PWM_Init(); //电机初始化

    memset((uint8_t *) &currentDataPoint, 0, sizeof(dataPoint_t));

    /** Warning !!! DataPoint Variables Init , Must Within The Data Range **/
    /*
      currentDataPoint.valueAutomatic_follow = ;
      currentDataPoint.valuefan = ;
      currentDataPoint.valueWireless_charging = ;
      currentDataPoint.valueFan_lift = ;
      currentDataPoint.valueTemperature = ;
      currentDataPoint.valueHumidity = ;
      currentDataPoint.valuePower_rating = ;
      currentDataPoint.valueGas = ;
      currentDataPoint.valueTemperature_alarm = ;
      currentDataPoint.valueHumidity_alarm = ;
      currentDataPoint.valueGas_alarmm = ;
      currentDataPoint.valuePower_low = ;
    */

}


/**
* @brief Millisecond timing maintenance function, milliseconds increment, overflow to zero

* @param none
* @return none
*/
void gizTimerMs(void) {
    timerMsCount++;
}

/**
* @brief Read millisecond count

* @param none
* @return millisecond count
*/
uint32_t gizGetTimerCount(void) {
    return timerMsCount;
}

/**
* @brief MCU reset function

* @param none
* @return none
*/
void mcuRestart(void) {
    __set_FAULTMASK(1);
    HAL_NVIC_SystemReset();
}

/**@} */

#ifdef __GNUC__
/* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
   set to 'Yes') calls __io_putchar() */
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */
/**
  * @brief  Retargets the C library printf function to the USART.
  * @param  None
  * @retval None
  */
PUTCHAR_PROTOTYPE {
    /* Place your implementation of fputc here */
    /* e.g. write a character to the USART1 and Loop until the end of transmission */
    HAL_UART_Transmit(&huart1, (uint8_t *) &ch, 1, 0xFFFF);

    return ch;
}


/**
  * @brief  This function handles USART IDLE interrupt.
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *UartHandle) {
    if (UartHandle->Instance == USART2) {
        gizPutData((uint8_t *) &aRxBuffer, 1);

        HAL_UART_Receive_IT(&huart2, (uint8_t *) &aRxBuffer, 1);//开启下一次接收中断
    }
}

/**
* @brief USART init function

* Serial communication between WiFi modules and device MCU
* @param none
* @return none
*/
void uartInit(void) {
    HAL_UART_Receive_IT(&huart2, (uint8_t *) &aRxBuffer, 1);//开启下一次接收中断
}

/**
* @brief Serial port write operation, send data to WiFi module
*
* @param buf      : buf address
* @param len      : buf length
*
* @return : Return effective data length;-1，return failure
*/
int32_t uartWrite(uint8_t *buf, uint32_t len) {
    uint8_t crc[1] = {0x55};
    uint32_t i = 0;

    if (NULL == buf) {
        return -1;
    }

    for (i = 0; i < len; i++) {
        HAL_UART_Transmit_IT(&huart2, (uint8_t *) &buf[i], 1);
        while (huart2.gState != HAL_UART_STATE_READY);//Loop until the end of transmission

        if (i >= 2 && buf[i] == 0xFF) {
            HAL_UART_Transmit_IT(&huart2, (uint8_t *) &crc, 1);
            while (huart2.gState != HAL_UART_STATE_READY);//Loop until the end of transmission
        }
    }

#ifdef PROTOCOL_DEBUG
    GIZWITS_LOG("MCU2WiFi[%4d:%4d]: ", gizGetTimerCount(), len);
    for (i = 0; i < len; i++) {
        GIZWITS_LOG("%02x ", buf[i]);

        if (i >= 2 && buf[i] == 0xFF) {
            GIZWITS_LOG("%02x ", 0x55);
        }
    }
    GIZWITS_LOG("\n");
#endif

    return len;
}  
