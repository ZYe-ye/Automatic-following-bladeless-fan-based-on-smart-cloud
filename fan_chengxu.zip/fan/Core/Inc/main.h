/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stm32f1xx.h"
#include "retarget.h"
#include "sys.h"
#include "delay.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */
extern char ch;
extern uint16_t mode_follow;
/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define KEY1_Pin GPIO_PIN_0
#define KEY1_GPIO_Port GPIOC
#define KEY2_Pin GPIO_PIN_1
#define KEY2_GPIO_Port GPIOC
#define relay1_Pin GPIO_PIN_2
#define relay1_GPIO_Port GPIOC
#define relay2_Pin GPIO_PIN_3
#define relay2_GPIO_Port GPIOC
#define MQ135_Pin GPIO_PIN_1
#define MQ135_GPIO_Port GPIOA
#define IN4_Pin GPIO_PIN_5
#define IN4_GPIO_Port GPIOA
#define ENA_Pin GPIO_PIN_6
#define ENA_GPIO_Port GPIOA
#define ENB_Pin GPIO_PIN_7
#define ENB_GPIO_Port GPIOA
#define IN3_Pin GPIO_PIN_4
#define IN3_GPIO_Port GPIOC
#define IN2_Pin GPIO_PIN_5
#define IN2_GPIO_Port GPIOC
#define ENC_Pin GPIO_PIN_0
#define ENC_GPIO_Port GPIOB
#define END_Pin GPIO_PIN_1
#define END_GPIO_Port GPIOB
#define IN1_Pin GPIO_PIN_2
#define IN1_GPIO_Port GPIOB
#define IN5_Pin GPIO_PIN_10
#define IN5_GPIO_Port GPIOB
#define IN6_Pin GPIO_PIN_12
#define IN6_GPIO_Port GPIOB
#define IN7_Pin GPIO_PIN_13
#define IN7_GPIO_Port GPIOB
#define IN8_Pin GPIO_PIN_14
#define IN8_GPIO_Port GPIOB
#define relay3_Pin GPIO_PIN_15
#define relay3_GPIO_Port GPIOB
#define DHT11_Pin GPIO_PIN_6
#define DHT11_GPIO_Port GPIOC
#define relay6_Pin GPIO_PIN_5
#define relay6_GPIO_Port GPIOB
#define relay5_Pin GPIO_PIN_8
#define relay5_GPIO_Port GPIOB
#define relay4_Pin GPIO_PIN_9
#define relay4_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
