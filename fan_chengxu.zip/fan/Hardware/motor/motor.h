#ifndef _MOTOR_H
#define _MOTOR_H

#define MOTOR_IN1  PBout(2)
#define MOTOR_IN2  PCout(5)
#define MOTOR_IN3  PCout(4)
#define MOTOR_IN4  PAout(5)
#define MOTOR_IN5  PBout(10)
#define MOTOR_IN6  PBout(12)
#define MOTOR_IN7  PBout(13)
#define MOTOR_IN8  PBout(14)



void motor_PWM_Init();
void MOTOR_forward();
void MOTOR_backward();
void MOTOR_left();
void MOTOR_right();
void MOTOR_stop();
void automatic_following();
void Close_to_follow();

#endif /*_MOTOR_H*/

